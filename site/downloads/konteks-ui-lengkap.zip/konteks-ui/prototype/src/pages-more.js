/* ---------- Agent session (/?conversation=…): same header, transcript, cycle stepper and composer as live ---------- */
function stepperHtml() { return `<div class="stepper" aria-label="Cycle 2 steps">${[["Estimate", 1], ["Quote", S.approved ? 1 : 2, "2.15 SP · $0.57–$2.02"], ["Plan", S.approved ? 2 : 0, "0/1"], ["Delivery", 0], ["Receipt", 0]].map(([l, s, sub], n) => `${n ? '<span class="step-line"></span>' : ""}<span class="step ${s === 1 ? "done" : s === 2 ? "now" : ""}" ${s === 2 ? 'aria-current="step"' : ""}><span class="n">${s === 1 ? ic("check") : n + 1}</span>${l}${sub ? `<small>${sub}</small>` : ""}</span>`).join("")}</div>`; }
function pageSession() {
  const can = S.viewAs === "approver";
  const top = `<a class="back" href="#initiative">${ic("arrow-left")}Back to Refresh the Support API README</a>
    <div class="top-r">
      <button class="tag tagbtn" type="button" id="rtChip" aria-label="Runtime rf-01, Ready">${ic("server")}rf-01 ${st("ok", "Ready")}</button>
      <button class="tag tagbtn" type="button" id="vcsChip" aria-label="Repository rentify/support-api on Gitea" data-tip="Gitea · Rentify org">${ic("git-branch")}<span class="mono">rentify/support-api</span></button>
      <button class="btn btn-ghost btn-sm" id="sysMap">${ic("map")}System map</button>
      <button class="btn btn-ghost btn-sm" id="files">${ic("folder")}Session files</button>
      ${viewAsToggle()}
    </div>`;
  const body = `<div class="sess">
    <div class="sess-scroll"><div class="sess-col">
      <div class="sess-ticket"><span class="idc">TKT-1</span><h1 class="h-page">Validate and refresh the support-api README</h1>${sysTag("rentify")}</div>
      <details class="inline-disc"><summary>${ic("chevron-right")}Ticket and acceptance criteria</summary><div class="disc-in prose"><p>Update only the existing README from current source and configuration, validate the documented workflows on rf-01, and leave one independently reviewed README-only pull request unmerged.</p><ol><li>Only the existing README changes.</li><li>Purpose, boundaries, flows and workflows are explained from current source.</li><li>Environment variable names only; no secret values.</li><li>Documented commands are executed on rf-01; outcomes are recorded as passed, failed or unavailable.</li></ol></div></details>
      <div class="evgroup">
      <div class="evline ok">${ic("receipt")}<b>Analysis quote ready: 2.15 SP</b><span>· valid until 27 Oct 2026, 14.34</span></div>
      <div class="evline ok">${ic("receipt")}<b>Execution quote ready: 2.15 SP</b><span>· valid until 27 Oct 2026, 16.20</span></div>
      <div class="evline ok">${ic("circle-check")}<b>Maya Lestari approved this delivery</b><span>· 15.22</span></div>
      <div class="evline">${ic("play")}<span>Task 1 of 1 started: Refresh and validate the support-api README · 15.22</span></div>
      <div class="evline">${ic("flag")}<span>The run has ended. Story Points settled · 17.19</span></div>
      </div>
      <div class="run"><div class="run-h">${ic("circle-stop")}<b style="font-weight:600">Not finished · your changes are kept on the pull request</b><span class="hint" style="margin-left:auto">0.47 SP</span></div>
        <div class="run-b"><p>Stopped by Maya Lestari. Work resumes only when someone chooses Continue.</p><div class="run-acts"><span class="tag">${ic("git-pull-request")}PR #41 · open</span><button class="btn btn-sm" id="viewChanges">${ic("file-diff")}View changes</button><button class="btn btn-sm" id="viewReceipt">${ic("receipt")}View receipt</button></div></div></div>
      <div class="msg-user">Before we retry: run the documented checks again on rf-01 and tell me which ones fail, and why.</div>
      <div class="msg-agent"><span class="agent-av">${ic("bot")}</span><div class="msg-b">
        <span class="who"><b>Konteks</b>Codex · GPT-6-Luna · 17.26</span>
        ${fmtMsg("Ran the six documented commands on rf-01:\n\n- `npm ci`: passed\n- `npm run seed:support`: passed\n- `npm run lint`: passed\n- `npm test`: passed, 212 tests\n- `npm run verify`: passed, but it prints an Asana error\n- `curl localhost:8080/health/ready`: passed\n\nThe Asana error comes from a test that checks rejection logging. It is expected, and it is what the last run misread as a failure. Nothing actually fails.")}
        <details class="trace"><summary title="41.2s · 1,840 tokens in, 310 out">${ic("chevron-right")}Agent trace</summary><pre>run    npm ci                     ok   18.4s
run    npm run seed:support       ok    3.1s
run    npm run lint               ok    6.0s
run    npm test                   ok   11.9s  212 passed
run    npm run verify             ok    1.2s  stderr: Asana 401 (expected)
run    curl /health/ready         ok    0.1s  200</pre></details>
      </div></div>
      <div class="msg-user">That makes sense. Note it so the next run doesn't stop on it again.</div>
      <div class="msg-agent"><span class="agent-av">${ic("bot")}</span><div class="msg-b">
        <span class="who"><b>Konteks</b>Codex · GPT-6-Luna · 17.29</span>
        <p>Noted under “Konteks learned” for this System. The next delivery treats the Asana message from <code>npm run verify</code> as expected output.</p>
      </div></div>
      <div class="msg-user">Please deliver this ticket again, fixing what stopped it last time.</div>
      <div class="msg-agent"><span class="agent-av">${ic("bot")}</span><div class="msg-b">
        <span class="who"><b>Konteks</b>Codex · GPT-6-Luna · 17.32</span>
        <p>I'll ask for a fresh estimate using the original ticket and your instruction. The new proposal accounts for the earlier misread check, and it needs approval before anything runs.</p>
        <div class="summary"><dl><dt>Last run</dt><dd>Stopped by Maya Lestari · 0.47 SP settled</dd><dt>Kept</dt><dd>PR #41 with the README changes, unmerged</dd><dt>Next</dt><dd>A new quote appears here for approval</dd></dl></div>
        <details class="trace"><summary title="30.5s · 990 tokens in, 22 out">${ic("chevron-right")}Agent trace</summary><pre>read   delivery receipt TKT-1 (stopped by user)
read   last proposal request: cancelled before a result
decide new proposal; no second delivery or charge started
submit proposal (ticket verbatim + retry instruction)</pre></details>
      </div></div>
      <div class="dc ${S.approved ? "waiting" : "decision"}"><div class="dc-top">${S.approved ? st("info", "Delivering") : st("ok", "Needs a decision")}<span>${S.approved ? "Started just now" : "Waiting 18m"}</span></div>
        <div class="dc-body"><div class="dc-title">${S.approved ? "TKT-1's delivery started" : "TKT-1's estimate is ready"}</div>
          ${S.approved ? `<p class="dc-why">Approved up to 2.15 SP. You'll be asked to review when the pull request is ready.</p>` : `<div class="quote"><div class="qrow"><span>Story Points, at most</span><b>2.15 SP</b></div><div class="qrow"><span>Model cost on your subscription</span><b>$0.57 – $2.02</b></div></div>
          <div class="dc-acts">${can ? `<button class="btn btn-primary btn-sm" id="sApprove">${ic("check")}Approve<span class="cost">2.15 SP</span></button>` : `<span class="gate">${ic("lock")}Waiting for a Delivery Approver (Maya Lestari)</span>`}<a class="btn btn-sm" href="#initiative">Change in the initiative${ic("arrow-right")}</a></div>`}</div></div>
      <details class="inline-disc"><summary>${ic("chevron-right")}Konteks learned · 1 note</summary><div class="disc-in hint">The verify script prints an expected Asana error from a rejection-logging test. It is not the cause of a failed check.</div></details>
      <div class="sess-live" id="sessLive"></div>
    </div></div>
    <div class="sess-foot"><div class="sess-col">
      <div class="cx-meta"><button class="prog-pill" type="button" id="progPill" aria-haspopup="dialog" aria-label="Cycle 2 of 2: ${S.approved ? "Plan, 0 of 1 tasks" : "Quote, 2.15 SP"}. Show all steps">${S.approved ? `<span class="pp-dot now"></span>Plan <small>0/1</small>` : `<span class="pp-dot now"></span>Quote <small>2.15 SP</small>`}<span class="pp-sep"></span><span class="hint">Cycle 2 of 2</span>${ic("chevron-up")}</button><span class="hint">Konteks can make mistakes. Verify important information.</span></div>
      <div class="atts" id="sessAtts"></div>${composerHtml({ id: "sessCx", placeholder: "Describe the outcome you need. Type / for a skill", cta: "Send", attachId: "sessAtts", compact: true, lead: `<button class="btn btn-ghost btn-icon btn-sm" type="button" aria-label="Create text attachment" data-tip="Create text attachment" id="txtAtt">${ic("file-plus-2")}</button><button class="btn btn-ghost btn-icon btn-sm" type="button" aria-label="Record voice message" data-tip="Record voice message" id="voiceBtn" aria-pressed="false">${ic("mic")}</button>` })}
    </div></div>
  </div>`;
  return shell("work", top, body, { flush: true });
}
function bindSession() {
  bindViewAs(render);
  $("#sApprove")?.addEventListener("click", () => approveDialog(() => { S.approved = true; render(); toast("Approved up to 2.15 SP. TKT-1's delivery started"); }));
  $("#sysMap")?.addEventListener("click", () => systemMap("Rentify"));
  $("#files")?.addEventListener("click", () => drawer("Session files", `<div class="empty"><div class="ic">${ic("folder-open")}</div><h3>No files in this session</h3><p>Attach screenshots, specs or logs with the paperclip in the message box. The agent reads them for this ticket only.</p></div>`));
  $("#viewChanges")?.addEventListener("click", changesDrawer);
  $("#viewReceipt")?.addEventListener("click", () => drawer("Receipt · TKT-1", `<div class="quote"><div class="qrow"><span>Result</span><b style="font-family:var(--sans)">Not finished, work kept</b></div><div class="qrow"><span>Settled</span><b>0.47 SP</b></div><div class="qrow"><span>Approved limit</span><b>2.15 SP</b></div><div class="qrow"><span>Model cost on your subscription</span><b>$0.41</b></div><div class="qrow"><span>Pull request</span><b>#41 · open</b></div></div>
    <div class="props">${[["Runtime", "rf-01"], ["Started", "27 Oct 2026, 15.22"], ["Ended", "27 Oct 2026, 17.19"], ["Stopped by", "Maya Lestari"]].map(([a, b]) => `<div class="prop"><span>${a}</span><div>${b}</div></div>`).join("")}</div>`));
  $("#rtChip")?.addEventListener("click", () => { S.rt = "rf-01"; location.hash = "runtime"; });
  $("#vcsChip")?.addEventListener("click", () => drawer("Repository", `<div class="props">${[["Connection", "Rentify org · Gitea"], ["URL", `<span class="mono">https://gitea.example.id/rentify/support-api</span>`], ["Branch", `<span class="mono">konteks/tkt-1-readme</span>`], ["Pull request", "#41 · open"]].map(([a, b]) => `<div class="prop"><span>${a}</span><div>${b}</div></div>`).join("")}</div>`));
  $("#progPill")?.addEventListener("click", e => {
    const p = popover(e.currentTarget, "Cycle progress", `<div class="prog-pop"><div class="pp-h"><b>Cycle 2 of 2</b><span class="hint">current</span></div>${stepperHtml()}<div class="pp-f"><button class="btn btn-ghost btn-sm" type="button" data-cycprev>${ic("chevron-left")}Cycle 1</button></div></div>`);
    drawIcons(); p.el.querySelector("[data-cycprev]").onclick = () => { p.close(); toast("Cycle 1: estimate, quote, plan and a delivery that stopped"); };
  });
  $("#txtAtt")?.addEventListener("click", () => { const m = modal("Create text attachment", `<div class="field"><label for="taName">Name</label><input id="taName" class="input" placeholder="e.g. error-log.txt"></div><div class="field"><label for="taBody">Text</label><textarea id="taBody" class="textarea mono-area" rows="8" placeholder="Paste a log, a spec or notes"></textarea></div>`, `<button class="btn" data-close>Cancel</button><button class="btn btn-primary" id="taOk" disabled>Attach</button>`); const chk = () => m.querySelector("#taOk").disabled = !(m.querySelector("#taName").value.trim() && m.querySelector("#taBody").value.trim()); m.querySelector("#taName").oninput = chk; m.querySelector("#taBody").oninput = chk; m.querySelector("#taOk").onclick = () => { closeOverlay(); toast("Text attached to the message"); }; });
  bindNoteTools();
  $("#voiceBtn")?.addEventListener("click", e => { const b = e.currentTarget, on = b.getAttribute("aria-pressed") !== "true"; b.setAttribute("aria-pressed", on); b.classList.toggle("rec", on); b.setAttribute("aria-label", on ? "Stop recording" : "Record voice message"); toast(on ? "Recording. Select the microphone again to stop" : "Recording added to your message"); });
  const live = $("#sessLive"), scroller = $(".sess-scroll");
  bindComposer($("#sessCx"), { onSend: ({ text, picks }) => {
    const box = $("#sessAtts"), names = [...box.querySelectorAll(".att b")].map(b => b.textContent); box.innerHTML = "";
    live.insertAdjacentHTML("beforeend", `<div class="msg-user msg-in">${text ? esc(text) : ""}${names.length ? `<span class="hint" style="display:block">${names.map(esc).join(", ")}</span>` : ""}${picks.length ? `<span class="msg-uses">${picks.map(p => `${p.kind === "skill" ? "Skill" : "Tool"} · ${esc(p.name)}`).join(", ")}</span>` : ""}</div>`);
    sfx("send"); agentRun(live, { text, picks, mode: "session", scroller });
  } });
}
function systemMap(name = "Rentify") {
  const d = drawer("System map · " + name, `<p class="hint">Components and the repositories they are built from. Relationships come from the catalog reading; a reviewer confirms them.</p>
    <div class="canvas" id="mapD"><div class="zoom"><button class="btn btn-icon btn-sm" type="button" aria-label="Zoom in" data-tip="Zoom in" data-zoom="in">${ic("plus")}</button><button class="btn btn-icon btn-sm" type="button" aria-label="Zoom out" data-tip="Zoom out" data-zoom="out">${ic("minus")}</button><button class="btn btn-icon btn-sm" type="button" aria-label="Reset zoom" data-tip="Reset zoom" data-zoom="fit">${ic("rotate-ccw")}</button></div>
      <div class="canvas-in" id="mapDIn"><svg class="links" aria-hidden="true"></svg>
        <div class="mnode sys" style="left:calc(50% - 90px);top:20px"><span class="label">System</span><b>${esc(name)}</b></div>
        ${[["support-api", "4%", "Confirmed", "ok"], ["web-app", "calc(50% - 90px)", "Confirmed", "ok"], ["gmail-handler", "calc(96% - 180px)", "Not classified yet", "warn"]].map(([n, l, s, k]) => `<div class="mnode" style="left:${l};top:150px"><b>${n}</b><span class="mono hint">rentify/${n}</span>${st(k, s)}<button class="btn btn-sm" type="button" data-startsess>Start a session</button></div>`).join("")}
      </div></div>
    <div class="callout warn">${ic("info")}<span class="grow"><b>gmail-handler is not classified yet.</b> Its owner and runtime are unknown until someone confirms them.</span></div>`, "", "", { wide: true });
  /* Loading state (DS-10): the drawer opens at once with a skeleton shaped like the map, then the map fills in. */
  const cv = d.querySelector("#mapD"); cv.hidden = true;
  cv.insertAdjacentHTML("beforebegin", `<div class="canvas map-sk" aria-busy="true" aria-label="Loading the System map">${["180px", "140px", "200px"].map(w => `<span class="sk" style="width:${w};height:40px;border-radius:var(--r10)"></span>`).join("")}</div>`);
  setTimeout(() => { d.querySelector(".map-sk")?.remove(); cv.hidden = false; draw(); }, 500);
  let z = 1; $$("[data-zoom]", d).forEach(b => b.onclick = () => { z = b.dataset.zoom === "in" ? Math.min(1.6, z + .2) : b.dataset.zoom === "out" ? Math.max(.6, z - .2) : 1; d.querySelector("#mapDIn").style.transform = `scale(${z})`; });
  const map = d.querySelector("#mapD"), svg = map.querySelector("svg.links"); const draw = () => { const w = map.clientWidth; svg.innerHTML = [w * .04 + 90, w / 2, w * .96 - 90].map(x => `<path d="M${w / 2} 64 V110 H${x} V150" fill="none" stroke="var(--line-strong)" stroke-width="1.25"/>`).join(""); }; requestAnimationFrame(draw); new ResizeObserver(draw).observe(map);
  $$("[data-startsess]", d).forEach(b => b.onclick = () => { closeOverlay(); location.hash = "session"; });
}

/* ---------- Activities / Issues / Releases / Leaders ---------- */
/* Activities: a timeline of what people did, built to make the next move obvious. Every entry is a person;
   an agent's answer to that person sits inside the card as a reply.
   Feed = cards on a rail, newest first, the same initiative's earlier events that day folded into its card.
   Rail = Waiting on you (existing actions), Start something (Systems with nothing in progress). Live work is marked
   in the feed itself (the Live chip), so the rail does not repeat it. */
const actDay = m => { const t = new Date(NOW - m * 60000), today = new Date(NOW); today.setHours(0, 0, 0, 0);
  const diff = Math.round((today - new Date(t.getFullYear(), t.getMonth(), t.getDate())) / 864e5);
  return diff === 0 ? "Today" : diff === 1 ? "Yesterday" : t.toLocaleDateString("en-GB", { weekday: "long" }); };
/* Inside a day group the time alone is enough; the full date and the relative time sit in the tooltip. */
const tlTime = m => { const d = new Date(NOW - m * 60000); return `<time datetime="${d.toISOString()}" title="${relTime(m)} · ${fmtDate(d)}">${pad2(d.getHours())}.${pad2(d.getMinutes())}</time>`; };
const actWho = p => PEOPLE[p].name;
const actAv = p => av(p);
function actBody(e, i) {
  /* The request as its author wrote it (the first note), without the title it repeats. */
  /* Two lines at most; the full text is one click away on the initiative (and in the tooltip). */
  if (e.kind === "started") { const req = THREADS[i.id]?.[0]?.text || REQUESTS[i.id]; return req ? `<p class="tl-text tl-quoted" title="${esc(req)}">${esc(req)}</p>` : ""; }
  /* The header already says who stopped what, so the body starts after that sentence. */
  if (e.kind === "stopped") { const rest = i.detail.split(/(?<=\.)\s+/).slice(1).join(" "); return rest ? `<p class="tl-text">${esc(rest)}</p>` : ""; }
  return "";
}
/* Konteks's answer to the person who called it: a reply inside their card, never an entry of its own. */
function actReply(e, i) {
  const r = e.reply; if (!r) return "";
  /* One line says what Konteks did; below it only what that line does not already say. */
  let body = `<p class="tl-text">${esc(i.detail)}</p>`;
  if (r.kind === "estimate" && i.quote) body = `<p class="tl-quote"><b>${i.quote[0]}</b> at most<span aria-hidden="true">·</span><b>${i.quote[1]}</b> model cost on your subscription</p>`;
  if (r.kind === "delivering") body = `<div class="tl-prog" role="img" aria-label="${e.done} of ${e.of} tickets merged, ${e.ticket} delivering" title="${e.done} of ${e.of} merged · ${e.ticket} delivering">${Array.from({ length: e.of }, (_, n) => `<span class="${n < e.done ? "done" : n === e.done ? "now" : ""}"></span>`).join("")}</div>`;
  return `<div class="tl-reply"><span class="av av-kx" title="Konteks">${ic("bot")}</span><div class="tl-reply-b"><p class="tl-reply-h"><b>Konteks</b><span class="agent-chip">Agent</span><span class="tl-did">${esc(REPLY_HEAD[r.kind](e))}</span>${tlTime(r.m)}</p>${body}</div></div>`;
}
/* One comment on an Activities card: avatar, name, time, text, reactions only (no reply to a comment, as live). */
const actCmt = c => `<li>${actAv(c.p)}<div><p class="tl-cmt-h"><b>${actWho(c.p)}</b>${tlTime(c.m)}</p><p class="tl-cmt-t">${esc(c.text)}</p><div class="reacts"><button class="react react-add" type="button" aria-label="Add a reaction" aria-haspopup="true" aria-expanded="false">${ic("smile-plus")}</button></div></div></li>`;
function actCard({ e, earlier }) { const i = iniById[e.ini], live = e.reply?.kind === "delivering" && e.reply.m < 60, cta = actsNow(i) && e === ACTIVITY.find(x => x.ini === e.ini);
    const when = new Date(NOW - e.m * 60000);
    return `<li class="tl-item ${live ? "live" : ""}"><span class="tl-node">${actAv(e.p)}</span><article class="tl-card" data-ini="${i.id}" aria-label="${esc(actWho(e.p))} ${esc(ACT_VERB[e.kind](e))} ${esc(i.title)}">
      <header class="tl-h"><span class="tl-av-m" aria-hidden="true">${actAv(e.p)}</span><div class="tl-hb"><p class="tl-t"><b>${actWho(e.p)}</b> ${ACT_VERB[e.kind](e)} <a href="#initiative/activities" data-ini="${i.id}">${esc(i.title)}</a></p>
        <p class="tl-sub"><span class="tl-sys">${ic("box")}${esc(sysById[i.sys].name)}</span><span aria-hidden="true">·</span><a href="#initiative/activities" data-ini="${i.id}" class="tl-upd">${i.updates} updates</a></p></div>${live ? `<span class="tl-live"><span class="dot"></span>Live</span>` : ""}${tlTime(e.m)}</header>
      ${actBody(e, i)}${actReply(e, i)}
      ${earlier.length ? `<details class="tl-thread"><summary>${ic("chevron-right")}${earlier.length} earlier ${e.m < 1440 ? "today" : "that day"}</summary><ol>${earlier.map(x => `<li>${actAv(x.p)}<span><b>${actWho(x.p)}</b> ${x.kind === "started" ? "started it" : ACT_VERB[x.kind](x).replace(/ (in|for)$/, "")}</span>${tlTime(x.m)}</li>`).join("")}</ol></details>` : ""}
      <footer class="tl-f"><div class="reacts">${e.re.map(([em, n]) => `<button class="react" type="button" aria-pressed="false" data-react>${em} <span>${n}</span></button>`).join("")}<button class="react react-add" type="button" aria-label="Add a reaction" aria-haspopup="true" aria-expanded="false">${ic("smile-plus")}</button><button class="btn btn-ghost btn-sm" type="button" data-cmt aria-label="Comment on ${esc(i.title)}">${ic("message-square")}Comment</button>${(e.cm || []).length ? `<button class="cmt-count" type="button" data-cmts aria-expanded="false">${[...new Set(e.cm.map(c => c.p))].slice(0, 3).map(p => actAv(p)).join("")}<span>${e.cm.length} comment${e.cm.length > 1 ? "s" : ""}</span></button>` : ""}</div>
        ${cta ? `<a class="btn btn-primary btn-sm" href="#initiative/activities" data-ini="${i.id}">${esc(i.action)}${ic("arrow-right")}</a>` : e.reply?.kind === "estimate" && !S.approved ? `<span class="hint">${ic("lock")}Maya Lestari approves</span>` : ""}</footer>
      <div class="tl-band" hidden><ol class="tl-cmts" hidden>${(e.cm || []).map(actCmt).join("")}</ol></div>
    </article></li>`; }
/* Start something: each idle System is one row and one button. The name reads as a name (box icon, ink, no frame);
   the action reads as an action ("Start" and an arrow in accent ink), so the two no longer look alike. */
const quietRows = quiet => quiet.map(s => `<li><button class="qs-row" type="button" data-start="${s.id}" aria-label="Start an initiative in ${esc(s.name)}"><span class="qs-sys">${ic("box")}${esc(s.name)}</span><span class="qs-go">Start${ic("arrow-right")}</span></button></li>`).join("");
function pageActivities() {
  const evs = ACTIVITY.filter(e => (S.actMore || !e.more) && (!S.sys || iniById[e.ini].sys === S.sys)).sort((a, b) => a.m - b.m);
  /* Fold: per day, an initiative appears once; its older events that day ride inside the newest one. */
  const days = [];
  evs.forEach(e => { const d = actDay(e.m); let g = days.find(x => x.d === d); if (!g) days.push(g = { d, date: (t => `${t.getDate()} ${MON[t.getMonth()]} ${t.getFullYear()}`)(new Date(NOW - e.m * 60000)), cards: [] });
    const c = g.cards.find(x => x.e.ini === e.ini); c ? c.earlier.push(e) : g.cards.push({ e, earlier: [] }); });

  const feed = days.length ? days.map(g => `<li class="tl-day"><h2>${g.d}<span>${g.date}</span></h2></li>${g.cards.map(actCard).join("")}`).join("")
    : `<li class="tl-empty"><h3>Nothing moved in ${esc(sysById[S.sys].name)} yet</h3><p>Start an initiative and the planning agent picks it up.</p><button class="btn btn-primary btn-sm" type="button" data-start="${S.sys}">${ic("plus")}New initiative</button></li>`;
  const cardCount = days.reduce((n, g) => n + g.cards.length, 0);
  const cardTotal = new Set(ACTIVITY.filter(e => !S.sys || iniById[e.ini].sys === S.sys).map(e => actDay(e.m) + e.ini)).size;
  const waiting = INITIATIVES.filter(actsNow);
  const quiet = SYSTEMS.filter(s => !INITIATIVES.some(i => i.sys === s.id));
  const rail = `<aside class="act-rail" aria-label="Around you">
    <div class="rail-rest">
    <section class="rail-wait"><h3>Waiting on you<span class="count hot">${waiting.length}</span></h3>
      ${waiting.length ? `<ul class="wait-list">${waiting.map(i => `<li><span><b>${esc(i.title)}</b><small>${esc(i.cause)}</small></span><a class="btn btn-sm" href="#initiative/activities" data-ini="${i.id}">${esc(i.action)}</a></li>`).join("")}</ul>` : `<p class="hint">Nothing needs you right now.</p>`}</section>
    <section class="rail-start"><h3>Start something</h3><p class="hint">Systems with no initiative yet. The planning agent starts from a few sentences.</p>
      <ul class="quiet-list">${quietRows(quiet)}</ul>
      <button class="btn btn-primary btn-sm" type="button" data-start="">${ic("plus")}New initiative</button></section>
    </div></aside>
    <button class="start-sticker" type="button" id="startSticker" aria-haspopup="dialog" aria-expanded="false">${ic("plus")}<span>Start something</span>${quiet.length ? `<span class="ss-n" title="${quiet.length} Systems with nothing in progress" aria-label="${quiet.length} Systems with nothing in progress">${quiet.length}</span>` : ""}</button>`;
  const body = `<div class="pagehead framed">${phead("Activities", "What your team is moving across your Systems.")}${sysFilter()}</div>
    <div class="act"><div class="act-feed"><ol class="tl" role="feed" aria-label="Activities">${feed}</ol>
      ${days.length ? `<div class="pager list-pager">${S.actMore ? `<span>You're all caught up · ${cardCount} cards</span>` : `<button class="btn btn-sm" id="moreAct">Load more</button><span>Showing ${cardCount} of ${cardTotal}</span>`}</div>` : ""}</div>${rail}</div>`;
  return shell("activities", "", body, { flush: true });
}
function bindActivities() {
  bindSysFilter();
  bindNoteTools();
  $$("[data-ini]").forEach(a => a.addEventListener("click", () => { S.cur = a.dataset.ini; }));
  $$("[data-start]").forEach(b => b.onclick = () => newInitiative(b.dataset.start || S.sys));
  /* Narrow screens: Start something is a small sticker that stays in view; it opens the same list in a popover. */
  const sticker = $("#startSticker");
  if (sticker) sticker.onclick = () => {
    if ($(".floatpop")) { $$(".floatpop").forEach(p => p.remove()); sticker.setAttribute("aria-expanded", "false"); return; }
    const quiet = SYSTEMS.filter(s => !INITIATIVES.some(i => i.sys === s.id));
    const pp = popover(sticker, "Start something", `<div class="ss-pop"><b>Start something</b><p class="hint">Systems with no initiative yet. The planning agent starts from a few sentences.</p>
      <ul class="quiet-list">${quietRows(quiet)}</ul>
      <button class="btn btn-primary btn-sm" type="button" data-start="">${ic("plus")}New initiative</button></div>`);
    drawIcons(); sticker.setAttribute("aria-expanded", "true");
    $$("[data-start]", pp.el).forEach(b => b.onclick = () => { pp.close(false); sticker.setAttribute("aria-expanded", "false"); newInitiative(b.dataset.start || S.sys); });
    new MutationObserver((_, o) => { if (!pp.el.isConnected) { sticker.setAttribute("aria-expanded", "false"); o.disconnect(); } }).observe(document.body, { childList: true });
  };
  $$("[data-react]").forEach(b => b.onclick = () => { const on = b.getAttribute("aria-pressed") !== "true"; b.setAttribute("aria-pressed", on); const c = b.querySelector("span"); c.textContent = +c.textContent + (on ? 1 : -1); b.classList.remove("bump"); void b.offsetWidth; b.classList.add("bump"); });
  /* Comments on an Activities card (live, checked 28 Oct 2026) belong to the card: they do not appear on the initiative,
     and @konteks here calls nobody. The band at the foot of the card holds them (folded behind the count) and the box,
     which says so and points to the initiative's notes for handing work to Konteks. */
  const band = card => card.querySelector(".tl-band");
  const setCount = card => { const n = card.querySelectorAll(".tl-cmts > li").length, f = card.querySelector("[data-cmts]");
    if (!n) { f?.remove(); return; }
    if (!f) card.querySelector("[data-cmt]").insertAdjacentHTML("afterend", `<button class="cmt-count" type="button" data-cmts aria-expanded="true"><span></span></button>`);
    const c = card.querySelector("[data-cmts]"); c.querySelector("span:last-child").textContent = `${n} comment${n > 1 ? "s" : ""}`; };
  $$(".tl-card").forEach(card => card.addEventListener("click", e => {
    const fold = e.target.closest("[data-cmts]");
    if (fold) { const open = fold.getAttribute("aria-expanded") !== "true"; fold.setAttribute("aria-expanded", open); card.querySelector(".tl-cmts").hidden = !open; band(card).hidden = !open && !card.querySelector(".tl-cmt"); return; }
    const b = e.target.closest("[data-cmt]"); if (!b) return;
    const shut = () => { card.querySelector(".tl-cmt")?.remove(); b.setAttribute("aria-expanded", "false"); if (!card.querySelectorAll(".tl-cmts > li").length || card.querySelector(".tl-cmts").hidden) band(card).hidden = true; b.focus({ preventScroll: true }); };
    if (card.querySelector(".tl-cmt")) { S.cmtDraft[card.dataset.ini] = card.querySelector(".tl-cmt textarea").value; return shut(); }
    /* One comment box at a time: opening another closes this one and keeps what was typed for later. */
    $$(".tl-cmt").forEach(o => { const oc = o.closest(".tl-card"); S.cmtDraft[oc.dataset.ini] = o.querySelector("textarea").value; o._shut?.(); });
    const i = iniById[card.dataset.ini];
    band(card).hidden = false;
    band(card).insertAdjacentHTML("beforeend", `<div class="tl-cmt"><span class="av">AY</span><div class="tl-cmt-b"><p class="cx-ctx">Comment on <b>${esc(i.title)}</b></p><div class="compose"><textarea rows="1" placeholder="Add a comment…" aria-label="Comment on this card" aria-describedby="cmtNote-${i.id}"></textarea><button class="btn btn-ghost btn-sm" type="button" data-cx>Cancel</button><button class="btn btn-primary btn-sm" type="button" data-cp aria-label="Comment">${ic("arrow-up")}<span class="send-l">Comment</span></button></div>
      <p class="hint tl-cmt-note" id="cmtNote-${i.id}">Stays on this card. To hand work to Konteks, use @konteks on a note in <a href="#initiative/activities" data-ini="${i.id}" title="${esc(i.title)}">the initiative</a>.</p></div></div>`);
    const box = card.querySelector(".tl-cmt"), ta = box.querySelector("textarea");
    drawIcons();
    box.querySelector("[data-ini]").onclick = () => { S.cur = i.id; };
    b.setAttribute("aria-expanded", "true"); ta.value = S.cmtDraft[i.id] || ""; if (ta.value) composeGrow(ta); ta.focus();
    box._shut = shut;
    box.querySelector("[data-cx]").onclick = () => { delete S.cmtDraft[i.id]; shut(); };
    box.querySelector("[data-cp]").onclick = () => { const t = ta.value.trim(); if (!t) return ta.focus();
      const list = card.querySelector(".tl-cmts"); list.hidden = false;
      list.insertAdjacentHTML("beforeend", actCmt({ p: "ay", m: 0, text: t }).replace("<li>", '<li class="msg-in">'));
      list.lastElementChild.querySelector("time").outerHTML = "<time>now</time>";
      delete S.cmtDraft[i.id]; ta.value = ""; bindNoteTools(list.lastElementChild); drawIcons(); setCount(card); card.querySelector("[data-cmts]")?.setAttribute("aria-expanded", "true"); shut(); sfx("send"); toast("Comment posted on this card"); };
    ta.onkeydown = ev => { if (ev.key === "Escape") { ev.preventDefault(); ev.stopPropagation(); shut(); } };
  }));
  $("#moreAct")?.addEventListener("click", () => { S.actMore = true; render(); });
}

function pageIssues() {
  const body = `<div class="pagehead framed">${phead("Issues", "What is wrong, by severity.")}${sysFilter()}</div>
    <div class="empty page"><div class="ic">${ic("shield-check")}</div><h3>Nothing is open</h3><p>When something breaks, whether a person reports it or a telemetry channel sends an alert, it appears here, highest severity first.</p><a class="btn btn-sm" href="#operations">${ic("radio-tower")}Set up a telemetry channel</a></div>`;
  return shell("issues", "", body, { flush: true });
}

/* Releases, as live (read 6 Nov 2026): "Release candidates" first, then "Released". A row: what it is (Release candidate, or
   the version in mono), the System, when, the summary, and "N initiatives · SP". The row opens the release. */
const relWhen = m => `<time title="${relTime(m)} · ${fmtDate(new Date(NOW - m * 60000))}">${relTime(m)}</time>`;
function relRow(r) {
  const cand = r.status === "candidate";
  return `<li><a class="rel-row" href="#release" data-rel="${r.id}">
    <span class="rel-ic">${ic(cand ? "rocket" : "package")}</span>
    <span class="rel-b"><span class="rel-h"><b class="${cand ? "" : "mono"}">${cand ? "Release candidate" : esc(r.version)}</b><span class="tl-sys">${ic("box")}${esc(sysById[r.sys].name)}</span>${relWhen(r.m)}</span>
      <span class="rel-sum">${esc(r.summary)}</span>
      <span class="rel-meta">${r.items.length} initiative${r.items.length > 1 ? "s" : ""}<span aria-hidden="true">·</span><span class="mono">${r.sp} SP</span></span></span></a></li>`;
}
function pageReleases() {
  const mine = RELEASES.filter(r => !S.sys || r.sys === S.sys), cand = mine.filter(r => r.status === "candidate"), done = mine.filter(r => r.status === "released");
  const group = (h, list) => list.length ? `<section class="rel-sec" aria-labelledby="rel-${h.replace(/\s/g, "")}"><h2 class="grp-h" id="rel-${h.replace(/\s/g, "")}">${h}<span class="count">${list.length}</span></h2><ul class="rel-list">${list.map(relRow).join("")}</ul></section>` : "";
  const body = `<div class="pagehead framed">${phead("Releases", "Ready to ship first, then what shipped.")}${sysFilter()}</div>
    <div class="content framed-body">${mine.length ? group("Release candidates", cand) + group("Released", done)
      : `<div class="empty page"><div class="ic">${ic("rocket")}</div><h3>Nothing here yet</h3><p>Accepted initiatives gather into a release candidate for their System.</p><a class="btn btn-sm" href="#work">${ic("square-kanban")}See initiatives in progress</a></div>`}</div>`;
  return shell("releases", "", body, { flush: true });
}
function bindReleases() {
  bindSysFilter();
  $$("[data-rel]").forEach(a => a.addEventListener("click", () => { S.rel = a.dataset.rel; }));
}

/* Release detail, as live: back link, System and status, the name (Release candidate / version), one action
   (Ship for a candidate, Announce for a release), then one card: what will ship / what shipped, the state line,
   the settlement ("Settled over N deliveries · SP"), and below it the release's comments. */
function pageRelease() {
  const r = relById[S.rel] || RELEASES[0], cand = r.status === "candidate";
  const items = r.items.map(it => `<li>${actAv(it.p)}<div><b>${esc(it.title)}</b><small>${esc(it.note)}</small></div>${cand ? `<button class="btn btn-ghost btn-sm" type="button" data-unrel aria-label="Remove from release: ${esc(it.title)}">Remove from release</button>` : ""}</li>`).join("");
  const top = `<a class="back" href="#releases">${ic("arrow-left")}Back to Releases</a>`;
  const body = `<div class="page-col rel-page">
    <header class="rel-head"><div><p class="rel-tags"><span class="tl-sys">${ic("box")}${esc(sysById[r.sys].name)}</span><span class="tl-sys">${ic("tag")}${cand ? "Release candidate" : "Released"}</span></p>
      <h1 class="ph-t ${cand ? "" : "mono"}">${cand ? "Release candidate" : esc(r.version)}</h1></div>
      ${cand ? `<button class="btn btn-primary" type="button" id="relShip">${ic("rocket")}Ship</button>` : `<button class="btn btn-primary" type="button" id="relAnnounce">${ic("megaphone")}Announce</button>`}</header>
    <section class="dc rel-card" aria-labelledby="relWhat"><h2 class="h-sub" id="relWhat">${cand ? "What will ship" : "What shipped"}</h2>
      <ul class="rel-items">${items}</ul>
      ${cand ? `<p class="hint">Waiting to ship</p>` : `<p class="rel-sumtext">${esc(r.summary)}</p><p class="hint">Shipped by ${esc(PEOPLE[r.by].name)} · ${relWhen(r.m)}</p>`}
      <div class="rel-settle"><span>Settled over ${r.deliveries} deliver${r.deliveries > 1 ? "ies" : "y"}</span><i aria-hidden="true"></i><b class="mono">${r.sp} SP</b></div></section>
    <section class="rel-thread" aria-label="Comments"><ol class="tl-cmts" id="relCmts">${r.cm.map(actCmt).join("")}</ol>
      <div class="rel-compose-wrap"><p class="cx-ctx">Comment on this release</p><div class="compose rel-compose"><textarea rows="1" placeholder="Add a comment…" aria-label="Comment on this release"></textarea><button class="btn btn-primary btn-sm" type="button" id="relPost" aria-label="Post comment">${ic("arrow-up")}<span class="send-l">Post comment</span></button></div></div></section></div>`;
  return shell("releases", top, body);
}
function bindRelease() {
  const r = relById[S.rel] || RELEASES[0];
  $("#relShip")?.addEventListener("click", () => dialog(`Ship the release candidate for ${sysById[r.sys].name}?`, `${r.items.length} initiative${r.items.length > 1 ? "s" : ""} ship together. Settled so far: ${r.sp} SP.`, "Ship", () => toast("Demo: shipping is not simulated")));
  $("#relAnnounce")?.addEventListener("click", () => toast("Demo: Announce was not opened during the read-only check, so it is not simulated"));
  $$("[data-unrel]").forEach(b => b.addEventListener("click", () => dialog("Remove from release?", "The initiative stays accepted and joins the next release candidate.", "Remove", () => toast("Demo: not removed"))));
  const ta = $(".rel-compose textarea");
  $("#relPost").onclick = () => { const t = ta.value.trim(); if (!t) return ta.focus();
    $("#relCmts").insertAdjacentHTML("beforeend", actCmt({ p: "ay", m: 0, text: t }).replace("<li>", '<li class="msg-in">')); $("#relCmts").lastElementChild.querySelector("time").outerHTML = "<time>now</time>";
    bindNoteTools($("#relCmts").lastElementChild); drawIcons(); ta.value = ""; sfx("send"); toast("Comment posted"); };
  $$("#relCmts > li").forEach(li => bindNoteTools(li));
}

/* Leaders: a ranked list, not a spreadsheet. Fixed columns so numbers line up; the points bar shows distance
   to the top at a glance; your own row is marked, and on a phone the counts fold under the name. */
function pageLeaders() {
  const max = Math.max(...LEADERS.map(l => l.pts)) || 1;
  const pl = (n, one, many) => `${n} ${n === 1 ? one : many}`;
  const row = (l, n) => `<li class="lb-row ${l.p === "ay" ? "lb-me" : ""}">
      <span class="lb-rank num">${n + 1}</span>
      <span class="lb-who">${av(l.p)}<span class="lb-name"><b>${PEOPLE[l.p].name}</b>${l.p === "ay" ? '<span class="lb-you">You</span>' : ""}<small class="lb-sub">${pl(l.s, "started", "started")} · ${pl(l.c, "contribution", "contributions")} · ${pl(l.r, "reaction", "reactions")}</small></span></span>
      <span class="lb-n num">${l.s}</span><span class="lb-n num">${l.c}</span><span class="lb-n num">${l.r}</span>
      <span class="lb-pts"><b class="num">${l.pts}</b><span class="lb-bar" aria-hidden="true"><i style="width:${Math.max(2, Math.round(l.pts / max * 100))}%"></i></span></span></li>`;
  const body = `<div class="pagehead framed">${phead("Leaders", "People by involvement. Agents and models by value.")}</div><div class="content framed-body">
    <section class="sec lb"><div class="sec-title"><div><h2 class="h-sec">People</h2><p class="hint">Points = 5 for each initiative started, 2 for each contribution, 1 for each reaction.</p></div></div>
      <div class="lb-list" role="table" aria-label="People by points">
        <div class="lb-row lb-head" role="row" aria-hidden="true"><span>#</span><span>Person</span><span class="num">Started</span><span class="num">Contributions</span><span class="num">Reactions</span><span class="lb-pts"><span class="num">Points</span><span></span></span></div>
        <ol class="lb-ol">${LEADERS.map(row).join("")}</ol>
      </div></section>
    <section class="sec lb"><div class="sec-title"><div><h2 class="h-sec">Agents and models</h2><p class="hint">Value appears once delivered work reports it.</p></div></div>
      <div class="lb-list"><div class="lb-row lb-head lb-ag" aria-hidden="true"><span>Agent</span><span>Value</span><span class="num">Tokens</span></div>
        <ul class="lb-ol"><li class="lb-row lb-ag"><span class="lb-who"><span class="agent-av">${ic("bot")}</span><span class="lb-name"><b>Codex</b><small class="lb-sub">GPT-6-Luna</small></span></span><span class="hint">Value not reported yet</span><span class="num">32M</span></li></ul></div></section></div>`;
  return shell("leaders", "", body, { flush: true });
}

/* ---------- Sign in: Backstage sign-in page with the Google provider, as live ---------- */
/* Sign in: the live Backstage page with the Google provider only. The page is a field of stage glyphs, the product's
   own mark: work queued, moving, delivered, and the few waiting for a person. The sign-in sits in a clearing at the
   centre. Hover a waiting glyph to see what it waits for; pressing Sign in sets the waiting ones moving again. */
/* Three sign-in designs for comparison, one process: Google-only Backstage sign-in with the same help and error.
   A (/login) the field, B (/login#night) the dark contour night, C (/login#split) sign-in beside the product. */
const LOGIN_VARIANTS = [["", "Field"], ["night", "Night"], ["split", "Split"]];
function loginBits() {
  const busy = S.loginStep === "busy", err = S.loginStep === "error";
  return {
    err: err ? `<div class="callout danger" role="alert">${ic("circle-alert")}<span class="grow"><b>The Google sign-in window closed before it finished.</b> Allow pop-ups for app.konteks.io and try again.</span></div>` : "",
    btn: `<button class="btn btn-primary google" type="button" id="gBtn" ${busy ? 'disabled aria-busy="true"' : ""}>${busy ? `<span class="spin"></span>Waiting for Google…` : `${ic("log-in")}Sign in with Google`}</button>`,
    help: `<p class="auth-help">Use the Google account your workspace invited.</p>`,
    base: `<footer class="auth-base"><span>${ic("shield-check")}Runs on your team's computers. Konteks never holds a provider key.</span><span class="auth-demo"><span class="label">Demo</span><nav class="auth-vars" aria-label="Sign-in designs">${LOGIN_VARIANTS.map(([k, l]) => `<a href="#${k}" ${(S.loginVar || "") === k ? 'aria-current="page"' : ""}>${l}</a>`).join("")}</nav><button class="btn btn-ghost btn-sm" type="button" id="gErr">Show the error state</button></span></footer>`,
  };
}
function pageLogin() {
  if (S.loginVar === "night") return pageLoginNight();
  if (S.loginVar === "split") return pageLoginSplit();
  const busy = S.loginStep === "busy", err = S.loginStep === "error";
  return `<div class="auth">
    <canvas class="field" id="field" aria-hidden="true"></canvas>
    <div class="field-tip" id="fieldTip" role="presentation" hidden></div>
    <main class="auth-main" id="main" tabindex="-1">
      <div class="auth-card">
        <span class="auth-mark"><span class="brand-mark">K</span>Konteks</span>
        <h1>Your agents kept working.</h1>
        <p class="auth-lede">Plans, estimates and deliveries move on their own. The few that need a person are waiting for you.</p>
        ${err ? `<div class="callout danger" role="alert">${ic("circle-alert")}<span class="grow"><b>The Google sign-in window closed before it finished.</b> Allow pop-ups for app.konteks.io and try again.</span></div>` : ""}
        <button class="btn btn-primary google" type="button" id="gBtn" ${busy ? 'disabled aria-busy="true"' : ""}>${busy ? `<span class="spin"></span>Waiting for Google…` : `${ic("log-in")}Sign in with Google`}</button>
        <p class="auth-help">Use the Google account your workspace invited.</p>
        <ul class="auth-legend" aria-label="What the field shows"><li><i class="lg-d"></i>Delivered</li><li><i class="lg-p"></i>In progress</li><li><i class="lg-y"></i>Needs a person</li></ul>
      </div>
    </main>
    ${loginBits().base}
  </div>`;
}
/* B · Night: a dark matcha ground with slow contour lines and a quiet column; the agents' work drifts past below. */
function nightContours() {
  let out = "";
  for (let k = 0; k < 30; k++) {
    let d = "";
    for (let x = -60; x <= 1500; x += 30) {
      const y = 70 + k * 30 + 48 * Math.sin(x / 230 + k * .33) + 26 * Math.sin(x / 97 + k * .7) + 14 * Math.sin(x / 53 + k * 1.3) + k * k * .15 * Math.sin(x / 400);
      d += (x === -60 ? "M" : " L") + x + "," + y.toFixed(1);
    }
    out += `<path d="${d}" class="${k % 5 ? "" : "major"}"/>`;
  }
  return out;
}
const NIGHT_CHIPS = [["done", "PR #142 merged"], ["run", "TKT-2 delivering on rf-01"], ["plan", "Plan written · Rental checkout"], ["wait", "Estimate waits for approval"],
  ["done", "Receipt settled · 1.84 SP"], ["plan", "Breakdown ready · HRIS README"], ["run", "Planning · Invoice export"]];
function pageLoginNight() {
  const b = loginBits(), chips = NIGHT_CHIPS.map(([k, t]) => `<span class="n-chip"><i class="n-${k}"></i>${t}</span>`).join("");
  return `<div class="auth auth-n">
    <svg class="n-lines" viewBox="0 0 1440 900" preserveAspectRatio="xMidYMid slice" aria-hidden="true"><g>${nightContours()}</g></svg>
    <header class="n-top"><span class="auth-mark"><span class="brand-mark">K</span>Konteks</span></header>
    <main class="n-main" id="main" tabindex="-1">
      <div class="n-col">
        <span class="n-tile" aria-hidden="true"><span class="brand-mark">K</span></span>
        <h1>Sign in to Konteks</h1>
        <p class="auth-lede">Your agents kept working while you were away. A few things are waiting for you.</p>
        ${b.err}${b.btn}${b.help}
      </div>
      <div class="n-rail" aria-hidden="true"><div class="n-track">${chips}${chips}</div></div>
    </main>
    ${b.base}
  </div>`;
}
/* What Konteks stands for, as the product states it (PRODUCT.md › Positioning). */
const SPLIT_PROS = [["server", "On your runtimes", "Agents run on your team's computers. Konteks never holds a provider key."],
  ["calculator", "Quoted before it runs", "Every delivery has a price in Story Points before anything starts."],
  ["receipt", "Settled on use", "Only what was used is charged, with a receipt for each delivery."]];
/* C · Split: sign in on paper; the product itself on the moss panel beside it (the real Work In Progress page and a real decision card). */
function pageLoginSplit() {
  const b = loginBits(), v = S.viewAs; S.viewAs = "approver";
  const card = shotOf(attentionCard(iniById["INI-139"])); S.viewAs = v;
  return `<div class="auth auth-s">
    <section class="s-left">
      <header class="s-top"><span class="auth-mark"><span class="brand-mark">K</span>Konteks</span></header>
      <main class="s-form" id="main" tabindex="-1">
        <h1>Welcome back.</h1>
        <p class="auth-lede">Sign in to see what your agents moved and what is waiting for you.</p>
        ${b.err}${b.btn}${b.help}
        <div class="s-card-m" aria-hidden="true" inert>${card}</div>
      </main>
      ${b.base}
    </section>
    <aside class="s-right" aria-hidden="true" inert>
      <div class="s-head"><b>Nothing runs until a person approves it.</b><span>Agents plan, estimate and deliver on your own runtimes. You decide what spends.</span></div>
      <div class="s-stage"><div class="s-shot"><div class="ov-shot-in">${shotOf(pageWork())}</div></div>
      <div class="s-card">${card}</div></div>
      <ul class="s-pros">${SPLIT_PROS.map(([i, t, d]) => `<li>${ic(i)}<b>${t}</b><span>${d}</span></li>`).join("")}</ul>
    </aside>
  </div>`;
}
/* The field: one canvas, a glyph every 32px. Colours come from the tokens, so dark mode follows. */
const WAITS = ["Estimate ready · up to 2.15 SP", "Breakdown ready for review", "Plan ready: create tickets", "Repository needed for TKT-1", "Pull request ready for review", "Konteks asked a question about the plan", "Decide: continue TKT-1?"];
function startField(cv) {
  const ctx = cv.getContext("2d"), tip = $("#fieldTip"), still = matchMedia("(prefers-reduced-motion: reduce)").matches;
  const css = n => getComputedStyle(document.documentElement).getPropertyValue(n).trim();
  let C = {}, cells = [], W = 0, H = 0, step = 32, mouse = { x: -999, y: -999 }, last = performance.now(), hot = null;
  const pal = () => { C = { q: css("--line-strong"), p: css("--accent-fill"), d: css("--accent-strong"), y: css("--accent"), halo: css("--focus"), fill: css("--surface") }; };
  const size = () => {
    const r = cv.getBoundingClientRect(), dpr = Math.min(2, devicePixelRatio || 1); W = r.width; H = r.height;
    cv.width = W * dpr; cv.height = H * dpr; ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    step = W < 600 ? 28 : 32; const cols = Math.ceil(W / step) + 1, rows = Math.ceil(H / step) + 1, ox = (W - (cols - 1) * step) / 2, oy = (H - (rows - 1) * step) / 2;
    const old = cells; cells = [];
    for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) {
      const prev = old[r * cols + c], x = ox + c * step, y = oy + r * step, k = Math.random();
      cells.push(prev ? Object.assign(prev, { x, y }) : { x, y, s: k < .012 ? "y" : k < .36 ? "d" : k < .62 ? "p" : "q", t: Math.random(), v: .04 + Math.random() * .1, pop: 0, w: WAITS[(r * 7 + c * 3) % WAITS.length], z: 1 });
    }
  };
  /* The clearing: glyphs fade out around the sign-in card, whatever the window size, so the words always read. */
  const clear = () => {
    const card = $(".auth-card"), cr = card?.getBoundingClientRect(), r = cv.getBoundingClientRect();
    if (!cr) return cells.forEach(g => g.a = 1);
    const cx = cr.left - r.left + cr.width / 2, cy = cr.top - r.top + cr.height / 2, rx = cr.width / 2 + 70, ry = cr.height / 2 + 56;
    cells.forEach(g => { const d = Math.hypot((g.x - cx) / rx, (g.y - cy) / ry); g.a = d < 1 ? 0 : Math.min(1, (d - 1) / .45); });
  };
  const glyph = (g, now) => {
    if (!g.a) return;
    const A = g.a, near = Math.hypot(g.x - mouse.x, g.y - mouse.y), lift = still ? 1 : 1 + Math.max(0, 1 - near / 120) * .45;
    g.z += (lift - g.z) * .18; const R = 7 * g.z + (g.pop > 0 ? g.pop * 3 : 0);
    ctx.lineWidth = 2;
    if (g.s === "d") { ctx.fillStyle = C.d; ctx.globalAlpha = A * (.42 + g.pop * .5); ctx.beginPath(); ctx.arc(g.x, g.y, R - 1.5, 0, 7); ctx.fill(); return; }
    if (g.s === "y") {
      const pulse = still ? .5 : (Math.sin(now / 500 + g.x) + 1) / 2;
      ctx.fillStyle = C.halo; ctx.globalAlpha = A * (.45 + pulse * .5); ctx.beginPath(); ctx.arc(g.x, g.y, R + 6 + pulse * 4, 0, 7); ctx.fill();
      ctx.globalAlpha = A; ctx.lineWidth = 2.5; ctx.fillStyle = C.fill; ctx.strokeStyle = C.y; ctx.beginPath(); ctx.arc(g.x, g.y, R, 0, 7); ctx.fill(); ctx.stroke(); return;
    }
    ctx.strokeStyle = C.q; ctx.globalAlpha = A * .8; ctx.beginPath(); ctx.arc(g.x, g.y, R, 0, 7); ctx.stroke();
    if (g.s === "p") { ctx.globalAlpha = A; ctx.strokeStyle = C.p; ctx.beginPath(); ctx.arc(g.x, g.y, R, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * g.t); ctx.stroke(); }
  };
  const tick = now => {
    if (!cv.isConnected) { removeEventListener("resize", onResize); return; }
    const dt = Math.min(.05, (now - last) / 1000); last = now;
    ctx.clearRect(0, 0, W, H); ctx.globalAlpha = 1;
    for (const g of cells) {
      if (!still) {
        if (g.s === "p") { g.t += g.v * dt; if (g.t >= 1) { g.s = Math.random() < .015 ? "y" : "d"; g.t = 0; g.pop = 1; } }
        else if (g.s === "q" && Math.random() < .0016) { g.s = "p"; g.t = 0; }
        else if (g.s === "d" && Math.random() < .0009) { g.s = "q"; }
        else if (g.s === "y" && Math.random() < .0012) { g.s = "p"; g.t = 0; g.pop = 1; }
        if (g.pop > 0) g.pop = Math.max(0, g.pop - dt * 4);
      }
      glyph(g, now);
    }
    if (!still) requestAnimationFrame(tick);
  };
  const onResize = () => { size(); clear(); if (still) tick(performance.now()); };
  /* Hover: a waiting glyph names what it waits for. */
  cv.parentElement.addEventListener("pointermove", e => {
    const r = cv.getBoundingClientRect(); mouse = { x: e.clientX - r.left, y: e.clientY - r.top };
    hot = cells.find(g => g.s === "y" && g.a > .5 && Math.hypot(g.x - mouse.x, g.y - mouse.y) < 14) || null;
    if (hot && !e.target.closest(".auth-card,.auth-base")) { tip.hidden = false; tip.textContent = hot.w; tip.style.left = r.left + hot.x + "px"; tip.style.top = r.top + hot.y - 18 + "px"; } else tip.hidden = true;
  });
  cv.parentElement.addEventListener("pointerleave", () => { mouse = { x: -999, y: -999 }; tip.hidden = true; });
  new MutationObserver(() => pal()).observe(document.documentElement, { attributes: true, attributeFilter: ["data-theme"] });
  addEventListener("resize", onResize);
  pal(); size(); clear(); requestAnimationFrame(tick);
  /* Your decision unblocks the work: everything waiting starts moving. */
  return { release: () => cells.forEach(g => { if (g.s === "y") { g.s = "p"; g.t = 0; g.v = .35 + Math.random() * .3; g.pop = 1; } }) };
}
function bindLogin() {
  const f = $("#field") ? startField($("#field")) : null;
  /* Split: the product shot renders at 1280px and scales to the panel. */
  $$(".s-shot").forEach(box => { const fit = () => box.style.setProperty("--k", box.clientWidth / 1280); fit(); new ResizeObserver(fit).observe(box); });
  $("#gBtn")?.addEventListener("click", () => { f?.release(); sfx("ok"); S.loginStep = "busy"; const b = $("#gBtn"); b.disabled = true; b.setAttribute("aria-busy", "true"); b.innerHTML = `<span class="spin"></span>Waiting for Google…`; setTimeout(() => { S.loginStep = "idle"; location.hash = "work"; }, 1400); });
  $("#gErr")?.addEventListener("click", () => { S.loginStep = "error"; render(); });
}
